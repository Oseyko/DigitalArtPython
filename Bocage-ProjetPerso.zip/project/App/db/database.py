from sqlalchemy.orm import sessionmaker

from models.models import Artiste, Oeuvre, Base, engine

Base.metadata.bind = engine
DBSession = sessionmaker(bind=engine)
session = DBSession()


# ARTISTE
def add_artiste(**kwargs):
    new_artiste = Artiste(**kwargs)
    session.add(new_artiste)
    session.commit()


def add_all_artiste(list_artiste):
    session.add_all(list_artiste)
    session.commit()


def get_all_artistes():
    return session.query(Artiste).all()


def get_one_artiste(**kwargs):
    return session.query(Artiste).filter_by(**kwargs).first()


def del_artiste(**kwargs):
    session.delete(get_one_artiste(**kwargs))
    session.commit()

    
def add_oeuvre_to_artiste(oeuvre_id, artiste_id):
    the_artiste = get_one_artiste(artiste_id=artiste_id)
    the_artiste.oeuvres.append(get_one_oeuvre(oeuvre_id=oeuvre_id))
    session.add(the_artiste)
    session.commit()


# OEUVRE
def add_oeuvre(**kwargs):
    new_oeuvre = Oeuvre(**kwargs)
    session.add(new_oeuvre)
    session.commit()


def add_all_oeuvres(list_oeuvres):
    session.add_all(list_oeuvres)
    session.commit()


def get_all_oeuvres():
    return session.query(Oeuvre).all()


def get_one_oeuvre(**kwargs):
    return session.query(Oeuvre).filter_by(**kwargs).first()


def get_oeuvres_artiste(artiste_id):
    return session.query(Oeuvre).filter_by(artiste_id=artiste_id).all()

def del_oeuvre(**kwargs):
    session.delete(get_one_oeuvre(**kwargs))
    session.commit()




