from datetime import datetime

from sqlalchemy import create_engine, Table, Column, Float, Integer, String, Date, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
engine = create_engine('sqlite:///db.sqlite3')
Base = declarative_base()

Session = sessionmaker(bind=engine)
session = Session()

class Artiste(Base):
    __tablename__ = 'artiste'
    artiste_id = Column(Integer, primary_key=True, nullable=False)
    nom = Column(String)
    prenom = Column(String)
    nationalite = Column(String)
    date_naissance = Column(String)
    pseudonyme = Column(String, nullable=False)
    oeuvre_id = Column(Integer, ForeignKey('oeuvre.oeuvre_id'))
    oeuvres = relationship( "Oeuvre", back_populates="artiste")



    def __init__(self, pseudonyme,nom=None, prenom=None, nationalite=None, date_naissance=None ):
        self.nom = nom
        self.prenom = prenom
        self.nationalite = nationalite
        self.date_naissance = date_naissance
        self.pseudonyme = pseudonyme


class Oeuvre(Base):
    __tablename__ = 'oeuvre'
    oeuvre_id = Column(Integer, primary_key=True, nullable=False)
    nom = Column(String)
    date_creation = Column(String)
    type = Column(String, nullable=False)
    visibilite = Column(String)
    commentaire = Column(String)
    artiste = relationship("Artiste", back_populates="oeuvres")

    def __init__(self, type, nom=None, date_creation=None, visibilite=None, commentaire=None):
        self.nom = nom
        self.date_creation = date_creation
        self.type = type
        self.visibilite = visibilite
        self.commentaire = commentaire


Base.metadata.create_all(engine)
