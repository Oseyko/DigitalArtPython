from hud import hud
from db import database
import os
clear = lambda: os.system('cls')


def menu_artiste():
    stopArtiste = False
    while stopArtiste is False:
        try:
            print('------------------------')
            print('-------- ARTISTE -------')
            print('  1) Afficher tous les artistes')
            print('  2) Afficher les détails d\'un artiste choisi')
            print('  3) Ajouter un artiste')
            print('  4) Supprimer un artiste')
            print('  5) Ajouter une oeuvre d\'un artiste')
            print('  6) Afficher les oeuvres d\'un artiste')
            print('  7) Retour au menu principal')
            stop = True
            choiceArtiste = int(input("Entrez votre choix : ")) or 7
            if choiceArtiste == 1:
                hud.hud_print_artistes(database)
            elif choiceArtiste == 2:
                hud.hud_print_details_artiste(database)
            elif choiceArtiste == 3:
                hud.hud_add_artiste(database)
            elif choiceArtiste == 4:
                try:
                   hud.hud_del_artiste(database)
                except Exception:
                    print('Erreur lors de la suppression de l\'artiste, veuillez réessayer')
            elif choiceArtiste == 5:
                hud.hud_add_oeuvre_artiste(database)
            elif choiceArtiste == 6:
                hud.hud_print_oeuvres_artiste(database)
            else:
                stopArtiste = True
        except ValueError:
            pass
        except Exception as e:
            print(e)
            print('Erreur lors du choix, retour au menu principal')
            stopArtiste = True


def menu_oeuvre():
    stopOeuvre = False
    clear()
    while stopOeuvre is False:
        try:
            print('---------------------')
            print('------ OEUVRES -----')
            print('  1) Afficher les oeuvres')
            print('  2) Afficher les détails d\'une oeuvre')
            print('  3) Ajouter une oeuvre')
            print('  4) Supprimer une oeuvre')
            print('  5) Retour au menu principal ')
            choiceOeuvre = int(input("Entrez votre choix : ")) or 6
            if choiceOeuvre == 1:
                hud.hud_print_oeuvres(database)
            elif choiceOeuvre == 2:
                hud.hud_print_details_oeuvre(database)
            elif choiceOeuvre == 3:
                hud.hud_add_oeuvre(database)
            elif choiceOeuvre == 4:
                try:
                    hud.hud_del_oeuvre(database)
                except Exception:
                    print('Erreur lors de la suppression de l\'oeuvre, veuillez réessayer')
            else:
                stopOeuvre = True
        except ValueError:
            pass
        except Exception as e:
            print(e)
            print('Erreur lors du choix, retour au menu principal')
            stopOeuvre = True



if __name__ == "__main__":
    stop = False
    clear()
    while stop is False:
        print('---------------------')
        print('------- MENU --------')
        print('  1) Artistes')
        print('  2) Oeuvres')
        print('  3) Quitter')
        print('---------------------')
        try:
            menuChoice = int(input("Entrez votre choix : ")) or 4
            
            if menuChoice > 3:
                stop = True
            elif menuChoice == 1:
                menu_artiste()
            elif menuChoice == 2:
                menu_oeuvre()
            else:
                stop = True
        except ValueError:
            pass
        except Exception as e:
            raise e
