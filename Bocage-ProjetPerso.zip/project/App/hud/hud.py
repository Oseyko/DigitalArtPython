import os
clear = lambda: os.system('cls')
from models.models import Artiste

def hud_add_artiste(control):
    clear()
    pseudonyme = None
    while not pseudonyme:
        pseudonyme = input("Pseudonyme : ")
    nom = input("Nom [facultatif] : ") or None
    prenom = input("Prénom [facultatif] : ") or None
    nationalite = input("Nationalité [facultatif] : ") or None
    date_naissance = input("Date de naissance (AAAA-MM-JJ) [facultatif] : ") or None

    control.add_artiste(pseudonyme=pseudonyme,
                        nom=nom,
                        prenom=prenom,
                        nationalite=nationalite,
                        date_naissance=date_naissance)


def hud_print_artistes(control):
    clear()
    for artiste in control.get_all_artistes():
        print("N°{})  {} {} {}".format(artiste.artiste_id, artiste.pseudonyme, artiste.prenom, artiste.nom))


def hud_print_details_artiste(control):
    clear()
    hud_print_artistes(control)
    id_artiste = int(input("Entrez le N° de l'artiste : "))
    artiste = control.get_one_artiste(artiste_id=id_artiste)
    print("N°{}) {} {}".format(artiste.artiste_id, artiste.nom, artiste.prenom))
    print("Pseudonyme : {}".format(artiste.pseudonyme))
    print("Nationalité : {}".format(artiste.nationalite))
    print("Date de naissance : {}".format(artiste.date_naissance))
    print("Oeuvres :  {}".format(artiste.oeuvres))

def hud_print_oeuvres_artiste(control):
    clear()
    hud_print_artistes(control)
    id_artiste = int(input("Entrez le N° de l'artiste : "))
    for oeuvre in control.get_oeuvres_artiste(id_artiste):
        print("N°{})  {} ".format(oeuvre.oeuvre_id, oeuvre.nom))
        


def hud_del_artiste(control):
    clear()
    hud_print_artistes(control)
    art_id = int(input("Entrez le N° de l'artiste à supprimer : "))
    control.del_artiste(artiste_id=art_id)


def hud_print_oeuvres(control):
    clear()
    for oeuvre in control.get_all_oeuvres():
        print("N°{})  {}".format(oeuvre.oeuvre_id, oeuvre.nom))


def hud_print_details_oeuvre(control):
    clear()
    hud_print_oeuvres(control)
    oeuvre_id = int(input("Entrez le N° de l'oeuvre : "))
    oeuvre = control.get_one_oeuvre(oeuvre_id=oeuvre_id)
    clear()
    print("N°{})  {}".format(oeuvre.oeuvre_id, oeuvre.nom))
    print("Type : {}".format(oeuvre.type))
    print("Visibilité : {}".format(oeuvre.visibilite))
    print("Commentaire personnel : {}".format(oeuvre.commentaire))



def hud_add_oeuvre_artiste(control):
    clear()
    hud_print_oeuvres(control)
    oeuvre_id = int(input("Entrez le N° de l'oeuvre : "))
    clear()
    hud_print_artistes(control)
    artiste_id = int(input("Entrez le N° de l'artiste : "))
    control.add_oeuvre_to_artiste(oeuvre_id, artiste_id)

        
def hud_add_oeuvre(control):
    clear()
    type = None
    while not type:
        type = input("Type : ") or None
    nom = input("Nom [facultatif] : ") or None
    visibilite = input("Visibilité [facultatif] : ") or None
    date_creation = input("Date de création (AAAA-MM-JJ) [facultatif] : ") or None
    commentaire = input("Commentaire personnel [facultatif] : ") or None

    control.add_oeuvre(nom=nom, date_creation=date_creation, type=type, visibilite=visibilite, commentaire=commentaire)


def hud_del_oeuvre(control):
    clear()
    hud_print_oeuvres(control)
    oeuvre_id = input("Entrez le N° de l'oeuvre à supprimer : ")
    control.del_oeuvre(oeuvre_id=oeuvre_id)

